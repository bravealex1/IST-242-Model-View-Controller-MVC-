package Model;

public class Person {

    private String name;
    private int weight;
    private String hometown;
    private String highSchool;
    private Height height;

    public Person(String name, int weight, String hometown, String highSchool, Height height) {
        this.name = name;
        this.weight = weight;
        this.hometown = hometown;
        this.highSchool = highSchool;
        this.height = height;
    }

    public Person() {
        this.name = "";
        this.weight = 0;
        this.hometown = "N/A";
        this.highSchool = "N/A";
        this.height = new Height();
    }

    @Override
    public String toString() {
        return "Person{" + "name=" + name + ", height=" + height + ", weight=" + weight + ", hometown=" + hometown + ", highSchool=" + highSchool + '}';
    }

    public Height getHeight() {
        return height;
    }

    public void setHeight(Height height) {
        this.height = height;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getHometown() {
        return hometown;
    }

    public void setHometown(String hometown) {
        this.hometown = hometown;
    }

    public String getHighSchool() {
        return highSchool;
    }

    public void setHighSchool(String highSchool) {
        this.highSchool = highSchool;
    }

}