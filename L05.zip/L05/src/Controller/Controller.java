package Controller;

import Model.Model;
import View.View;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import javax.swing.JButton;
import java.awt.Color;
//import java.awt.event.ActionEvent;

//import java.awt.event.KeyEvent;
//import java.awt.event.KeyListener;
//import java.awt.event.MouseWheelEvent;
//import java.awt.event.MouseWheelListener;
//import java.util.ArrayList;
//import javax.swing.JTextField;
public class Controller {

    Model model;
    View view;
    int i;

    public Controller(View v, Model m) {
        model = m;
        view = v;
        i = 0;
        view.createHeaders(model.getFpData().getHeaders().size());
        view.writeOnHeaders(model.getFpData().getHeaders());

        for (int i = 0; i < model.getFpData().getLinesBeingDisplayed(); i++) {
            view.createLines(model.getFpData().getHeaders().size());
        }
        view.writeOnLines(model.getFpData().getLines(model.getFpData().getFirstLineToDisplay(), model.getFpData().getLastLineToDisplay()));
        addListeners();
        addMWL();
    }

    private void addListeners() {
        view.getIframe().getIp().getCp().getHeaders().get(0).addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton b = (JButton) e.getSource();
                b.setBackground(Color.red);
                model.getFpData().SetSortField(0);
                model.getFpData().sort();
                view.getIframe().getIp().getCp().writeOnLines(model.getFpData().getLines(model.getFpData().getFirstLineToDisplay(), model.getFpData().getLastLineToDisplay()));
                System.out.println("button b0 was clicked");
            }
        }
        );

        view.getIframe().getIp().getCp().getHeaders().get(1).addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton b = (JButton) e.getSource();
                b.setBackground(Color.yellow);
                model.getFpData().SetSortField(1);
                model.getFpData().sort();
                view.getIframe().getIp().getCp().writeOnLines(model.getFpData().getLines(model.getFpData().getFirstLineToDisplay(), model.getFpData().getLastLineToDisplay()));
                System.out.println("button b0 was clicked");
            }
        }
        );
        view.getIframe().getIp().getCp().getHeaders().get(2).addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton b = (JButton) e.getSource();
                b.setBackground(Color.GREEN);
                model.getFpData().SetSortField(2);
                model.getFpData().sort();
                view.getIframe().getIp().getCp().writeOnLines(model.getFpData().getLines(model.getFpData().getFirstLineToDisplay(), model.getFpData().getLastLineToDisplay()));
                System.out.println("button b0 was clicked");
            }
        }
        );
        view.getIframe().getIp().getCp().getHeaders().get(3).addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton b = (JButton) e.getSource();
                b.setBackground(Color.ORANGE);
                model.getFpData().SetSortField(3);
                model.getFpData().sort();
                view.getIframe().getIp().getCp().writeOnLines(model.getFpData().getLines(model.getFpData().getFirstLineToDisplay(), model.getFpData().getLastLineToDisplay()));
                System.out.println("button b0 was clicked");
            }
        }
        );
        view.getIframe().getIp().getCp().getHeaders().get(4).addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton b = (JButton) e.getSource();
                b.setBackground(Color.blue);
                model.getFpData().SetSortField(4);
                model.getFpData().sort();
                view.getIframe().getIp().getCp().writeOnLines(model.getFpData().getLines(model.getFpData().getFirstLineToDisplay(), model.getFpData().getLastLineToDisplay()));
                System.out.println("button b0 was clicked");
            }
        }
        );
        view.getIframe().getIp().getCp().getHeaders().get(5).addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton b = (JButton) e.getSource();
                b.setBackground(Color.gray);
                model.getFpData().SetSortField(5);
                model.getFpData().sort();
                view.getIframe().getIp().getCp().writeOnLines(model.getFpData().getLines(model.getFpData().getFirstLineToDisplay(), model.getFpData().getLastLineToDisplay()));
                System.out.println("button b0 was clicked");
            }
        }
        );
        view.getIframe().getIp().getCp().getHeaders().get(6).addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton b = (JButton) e.getSource();
                b.setBackground(Color.yellow);
                model.getFpData().SetSortField(6);
                model.getFpData().sort();
                view.getIframe().getIp().getCp().writeOnLines(model.getFpData().getLines(model.getFpData().getFirstLineToDisplay(), model.getFpData().getLastLineToDisplay()));
                System.out.println("button b0 was clicked");
            }
        }
        );
    }

    private void addMWL() {
        view.getIframe().getIp().getCp().addMouseWheelListener(
                new MouseWheelListener() {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e) {
                System.out.println("wr=" + e.getPreciseWheelRotation());
                System.out.println("mu=" + e.getUnitsToScroll());
                i = i + e.getUnitsToScroll();
                model.getFpData().setFirstLineToDisplay(i);
                view.getIframe().getIp().getCp().writeOnLines(model.getFpData().getLines(model.getFpData().getFirstLineToDisplay(), model.getFpData().getLastLineToDisplay()));
            }
        }
        );
    }
}
