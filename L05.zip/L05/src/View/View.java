package View;

import java.util.ArrayList;

public class View {

    private InitialFrame iframe;

    public View() {
        iframe = new InitialFrame();
    }

    public void basicDisplay(String s) {
        System.out.println(s);
    }

    public void basicDisplay(ArrayList<String> arr) {
        for (int i = 0; i < arr.size(); i++) {
            System.out.print(arr.get(i) + " ");
        }
        System.out.println();
    }

    public void linesDisplay(ArrayList<ArrayList<String>> arrOfarr) {
        for (int i = 0; i < arrOfarr.size(); i++) {
            this.basicDisplay(arrOfarr.get(i));
        }
    }

    public void CenterInitialSetup(int linesBeingDisplayed, int size) {
        iframe.getInitialPanel().getCp().createHeaders(size);
        iframe.getInitialPanel().getCp().createLines(linesBeingDisplayed);
    }

    public void CenterUpdate(ArrayList<ArrayList<String>> buttons, ArrayList<String> headers) {
        iframe.getInitialPanel().getCp().writeOnLines(buttons);
       iframe.getInitialPanel().getCp().writeOnHeaders(headers);
    }

    public void createHeaders(int size) {
        iframe.getInitialPanel().getCp().createHeaders(size);
    }

    public void writeOnHeaders(ArrayList<String> names) {
        iframe.getInitialPanel().getCp().writeOnHeaders(names);
    }

    public void createLines(int size) {
        iframe.getInitialPanel().getCp().createLines(size);
    }

    public void writeOnLines(ArrayList<ArrayList<String>> getLine) {
        iframe.getInitialPanel().getCp().writeOnLines(getLine);

    }

    public InitialFrame getIframe() {
        return iframe;
    }

    public void setIframe(InitialFrame iframe) {
        this.iframe = iframe;
    }

}
