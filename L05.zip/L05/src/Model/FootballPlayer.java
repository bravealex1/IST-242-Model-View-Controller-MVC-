/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author PSU
 */
public class FootballPlayer extends Person implements TableMember {

     private int number;
     private String position;

    public FootballPlayer(int number, String position, String name, int weight, String hometown, String highSchool, Height height) {
        super(name, weight, hometown, highSchool, height);
        this.number = number;
        this.position = position;
    }

    public FootballPlayer() {
        super();
        this.number = 0;
        this.position = "N/A";
    }

    @Override
    public String toString() {
        return super.toString()
                + "FootballPlayer{" + "number=" + getNumber() + ", position=" + getPosition() + '}';
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @Override
    public String getAttribute(int n) {
//       ArrayList<String> list = getAttributes();
//        if (n == 0) {
//            System.out.println(number);
//        }
//        if (n == 1) {
//            System.out.println(position);
//        }
//        if (n == 2) {
//            System.out.println (name);
//        }
//        if (n == 3) {
//            System.out.println (weight);
//        }

        switch (n) {
            case 0:
                return String.valueOf(this.number);
            case 1:
                return this.position;
            case 2:
                return super.getName();
            case 3:
                return super.getHeight().toString();
            case 4:
                return String.valueOf(super.getWeight());
            case 5:
                return super.getHometown();
            case 6:
                return super.getHighSchool();
            default:
                return ("invalid input parameter");
        }
    }

    @Override
    public ArrayList<String> getAttributes() {
        ArrayList<String> getAttributes = new ArrayList<>();
        getAttributes.add(String.valueOf(this.number));
        getAttributes.add(this.position);
        getAttributes.add(super.getName());
        getAttributes.add(super.getHeight().toString());
        getAttributes.add(String.valueOf(super.getWeight()));
        getAttributes.add(super.getHometown());
        getAttributes.add(super.getHighSchool());
        //System.out.println();

//        for (int i = 0; i < getAttributes.size(); i++) {
//
//            System.out.println(getAttributes.add(getAttribute(i)));
//
//        }
        return getAttributes;
    }
    

    @Override
    public String getAttributeName(int n
    ) {

//        if ( n == 0) {
//            System.out.println("number");
//        }
//        if ( n == 0) {
//            System.out.println("position");
//        }
//        if ( n == 0) {
//            System.out.println("name");
//        }
//        if ( n == 0) {
//            System.out.println("weight");
//        }
//        if ( n == 0) {
//            System.out.println("hometown");
//        }
//        else {
//            return ("invalid input parameter");
//        }
        switch (n) {
            case 0:
                return "number";
            case 1:
                return "position";
            case 2:
                return "name";
            case 3:
                return "height";
            case 4:
                return "weight";
            case 5:
                return "hometown";
            case 6:
                return "highSchool";
            default:
                return ("invalid input parameter");
        }

    }

    @Override
    public ArrayList<String> getAttributeNames() {
        ArrayList<String> getAttributeNames = new ArrayList<>();
        getAttributeNames.add("number");
        getAttributeNames.add("position");
        getAttributeNames.add("name");
        getAttributeNames.add("height");
        getAttributeNames.add("weight");
        getAttributeNames.add("hometown");
        getAttributeNames.add("highschool");
        //System.out.println();

//        for (int i = 0; i < getAttributeNames.size(); i++) {
//
//            System.out.println(getAttributeNames.add(getAttributeName(i)));
//        }
        return getAttributeNames;
    }
}