/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import java.awt.Color;
import java.awt.GridLayout;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.*;

/**
 *
 * @author PSU
 */
public class CenterPanel extends JPanel {

    private ArrayList<JButton> headers;
    //ArrayList<JButton> lines;
    private ArrayList<JButton> buttons;

    CenterPanel() {
        super();
        headers = new ArrayList<>();
        //lines = new ArrayList<>();
        buttons = new ArrayList<>();
        this.setBackground(Color.pink);
        //this.createHeaders(headers.size());

    }

    public void createHeaders(int size) {
        for (int i = 0; i < size; i++) {
            JButton b1 = new JButton();
            add(b1);
            headers.add(b1);
        }
        this.setLayout(new GridLayout(0, size));
        this.validate();
        this.repaint();
        //this.createHeaders(headers.size());
    }

    public void writeOnHeaders(ArrayList<String> names) {
        for (int i = 0; i < names.size(); i++) {
            headers.get(i).setText(names.get(i));
        }
        //this.setLayout(new GridLayout(0, 10));
        this.validate();
        this.repaint();
    }

    public void createLines(int size) {
        for (int i = 0; i < size; i++) {
            //ArrayList JButton = new ArrayList<>();
            //b1.get(i);
            //buttons.add(b1.get(i));
            //add(b1);
            JButton b = new JButton();
            //JButton c = new JButton();
            //JButton.add(buttons.get(i));
            add(b);
            //add(c);
            buttons.add(b);
            //buttons.add(c);
            //buttons.get(i);
        }

        //this.setLayout(new GridLayout(0, size));
        this.validate();
        this.repaint();
    }

    public void writeOnLines(ArrayList<ArrayList<String>> lineData) {
        int k = 0;//will go from button 0 to button 140 (if you have 20 lines)
        for (int i = 0; i < lineData.size(); i++) // loop to read ONE line at once
        {

            for (int j = 0; j < lineData.get(i).size(); j++) //loop to break ONE line in SEVEN strings
            {
                buttons.get(k).setText(lineData.get(i).get(j));
                k++;
            }
            this.validate();
            this.repaint();
        }
    }

    public ArrayList<JButton> getHeaders() {
        return headers;
    }

    public void setHeaders(ArrayList<JButton> headers) {
        this.headers = headers;
    }

    public ArrayList<JButton> getButtons() {
        return buttons;
    }

    public void setButtons(ArrayList<JButton> buttons) {
        this.buttons = buttons;
    }
}
