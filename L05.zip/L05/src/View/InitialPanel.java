/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;
import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;


/**
 *
 * @author PSU
 */
public class InitialPanel extends JPanel
{
    private CenterPanel cp;

    public InitialPanel()
    {
        super();
        BorderLayout bl = new BorderLayout(5, 5);
        setLayout(bl);
        cp = new CenterPanel();
        //   add(np, BorderLayout.NORTH);
        //  add(sp, BorderLayout.SOUTH);
        //   add(wp, BorderLayout.WEST);
        add(cp, BorderLayout.CENTER);
    }

    /**
     * @return the cp
     */
    public CenterPanel getCp()
    {
        return cp;
    }

    /**
     * @param cp the cp to set
     */
    public void setCp(CenterPanel cp)
    {
        this.cp = cp;
    }
}

