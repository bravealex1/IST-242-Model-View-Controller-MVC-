package Model;

//import java.util.ArrayList;

public class Model
{

    private FootballPlayerData fpData;
    //ArrayList<TableMember> player;

    public Model() {
        //player = new ArrayList<>();
        fpData = new FootballPlayerData();
        //loadData();
    }

//    public void loadData() {
//        //name, weight, hometown, highschool, height
//        TableMember pl1, pl2, pl3, pl4, pl5;
//
////        pl1 = (new Person("Marcus Allen", 200, "Upper Marboro", "Md., highSchool=Dr. Henry A.Wise,Jr.", new Height(5, 2)));
////        TableMember.add(new Person("Kyle Alston", 180, "Robbinsville, N.J.,", "Robbinsville", new Height(5, 9)));
////        pl1 = (new Person("Troy Apke", 220, "Mt. Lebanon, Pa.,", "Mount Lebanon", new Height(6, 1)));
////        pers.add(new Person("Matthew Baney", 225, "State College, Pa.,", "State College", new Height(6, 0)));
////        pers.add(new Person());
//        //int number, String position, String name, int weight, String hometown, String highSchool, Height height)
//        pl1 = new FootballPlayer(2, "S", "Marcus Allen", 200, "Upper Marboro", "Md., highSchool=Dr. Henry A.Wise,Jr.", new Height(5, 2));
//        pl2 = new FootballPlayer(37, "CB", "Kyle Alston", 180, "Robbinsville, N.J.", "Robbinsville", new Height(5, 9));
//        pl3 = new FootballPlayer(28, "S", "Troy Apke", 220, "Mt. Lebanon, Pa.,", "Mount Lebanon", new Height(6, 1));
//        pl4 = new FootballPlayer(35, "LB", "Matthew Baney", 225, "State College, Pa.,", "State College", new Height(6, 0));
////        pl5 = new FootballPlayer();
////        player.add(pl1);
////        player.add(pl2);
////        player.add(pl3);
////        player.add(pl4);
////        player.add(pl5);
//        player.add(pl1);
//        player.add(pl2);
//        player.add(pl3);
//        player.add(pl4);
////      player.add(pl5);
//
//    }
//
//    public String getData(int n) {
//        return player.get(n).toString();
//    }
//
//    public ArrayList<String> getData() {
//        int n;
//        ArrayList<String> pers1;
//        pers1 = new ArrayList<>();
//        for (n = 0; n < player.size(); n++) {
//            pers1.add(getData(n));
//        }
//
//        return pers1;
//    }
//
//    public ArrayList<TableMember> getPers() {
//        return player;
//    }
//
//    public void setPers(ArrayList<TableMember> player) {
//        this.player = player;
//    }
//    
//    public ArrayList<TableMember> getMembers() {
//        return player;
//    }
//
//    public void setMembers(ArrayList<TableMember> members) 
//    {
//        this.player = members;
//    }

    public FootballPlayerData getFpData()
    {
        return fpData;
    }

    public void setFpData(FootballPlayerData fpd)
    {
        this.fpData = fpd;
    }
}
