package Model;

import java.beans.XMLDecoder;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class FootballPlayerData implements TableData, Displayable, Sortable {

    private ArrayList<TableMember> players;

    private int firstLineToDisplay;
    private int lastLineToDisplay;
    private int linesBeingDisplayed;

    private int lineToHighlight;
    private int sortField;

    public FootballPlayerData() {
        players = new ArrayList<>();
        loadTable();

        this.setLinesBeingDisplayed(15);

        this.setFirstLineToDisplay(0);

        this.setLineToHighlight(0);
    }

    @Override
    public void loadTable() {
        ReadPlayersFromXML();
    }

    public void ReadPlayersFromXML() {
        try {
            FootballPlayer fp;
            XMLDecoder decoder;
            decoder = new XMLDecoder(new BufferedInputStream(new FileInputStream("FootballPlayerTable.xml")));
            fp = new FootballPlayer();
            while (fp != null) {
                try {
                    fp = (FootballPlayer) decoder.readObject();
                    players.add(fp);

                } catch (ArrayIndexOutOfBoundsException theend) {
                    //System.out.println("end of file");
                    break;
                }
            }
            decoder.close();
        } catch (Exception xx) {
            xx.printStackTrace();
        }
    }

    @Override
    public ArrayList<TableMember> getTable() {
        return this.players;
    }

    @Override
    public ArrayList<String> getHeaders() {
        ArrayList<String> getAttributeNames = new ArrayList<>();
        getAttributeNames.add("number");
        getAttributeNames.add("position");
        getAttributeNames.add("name");
        getAttributeNames.add("height");
        getAttributeNames.add("weight");
        getAttributeNames.add("hometown");
        getAttributeNames.add("highschool");
        return getAttributeNames;
    }

    @Override
    public ArrayList<String> getLine(int line) {
        return players.get(line).getAttributes();
    }

    @Override
    public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine) {
        ArrayList<ArrayList<String>> getLine = new ArrayList<>();
        for (int n = firstLine; n <= lastLine; n++) {
            getLine.add(players.get(n).getAttributes());
        }
        return getLine;
    }

    @Override
    public int getFirstLineToDisplay() {
        return firstLineToDisplay;
    }

    @Override
    public int getLineToHighlight() {
        return 0;
    }

    @Override
    public int getLastLineToDisplay() {
        lastLineToDisplay = firstLineToDisplay + linesBeingDisplayed - 1;
        return lastLineToDisplay;
    }

    @Override
    public int getLinesBeingDisplayed() {
        return linesBeingDisplayed;
    }

    @Override
    public void setFirstLineToDisplay(int firstLine) {
        if (firstLine > (players.size() - linesBeingDisplayed)) {
            firstLineToDisplay = (players.size() - linesBeingDisplayed);
        }
        if (firstLine >= 0 && firstLine <= (players.size() - linesBeingDisplayed)) {
            firstLineToDisplay = firstLine;
        }
        if (firstLine < 0) {
            firstLineToDisplay = 0;
        }
        //firstLine = firstLineToDisplay;
    }

    @Override
    public void setLineToHighlight(int highlightedLine) {
        lineToHighlight = highlightedLine;
    }

    @Override
    public void setLastLineToDisplay(int lastLine) {
        if (lastLine > (players.size() - 1)) {
            lastLineToDisplay = (firstLineToDisplay + linesBeingDisplayed - 1);
        }
        if (lastLine >= 0 && lastLine <= (players.size() - 1)) {
            lastLineToDisplay = lastLine;
        }
        if (lastLine < 0) {
            lastLineToDisplay = 0;
        }
        //lastLineToDisplay = lastLine;
    }

    @Override
    public void setLinesBeingDisplayed(int numberOfLines) {
//        if (numberOfLines > (lastLineToDisplay - firstLineToDisplay + 1)) {
//            linesBeingDisplayed = lastLineToDisplay - firstLineToDisplay + 1;
//        } //        if (numberOfLines <= linesBeingDisplayed) {
        //            linesBeingDisplayed = numberOfLines;
        //        }
        if (numberOfLines < 0 || numberOfLines > players.size()) {
            linesBeingDisplayed = lastLineToDisplay - firstLineToDisplay + 1;
        } else {
            linesBeingDisplayed = numberOfLines;
        }
    }

    private Comparator sortPlayerByNumber = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer p1, FootballPlayer p2) {
            if (p1.getNumber() < (p2.getNumber())) {
                return -1;
            }
            if (p1.getNumber() == (p2.getNumber())) {
                return 0;
            }
            return 1;
        }
    };

    private Comparator sortPlayerByPosition = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer p1, FootballPlayer p2) {
            return p1.getPosition().compareTo(p2.getPosition());
        }
    };

    private Comparator sortPlayerByName = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer p1, FootballPlayer p2) {
            return p1.getName().compareTo(p2.getName());
        }
    };

    private Comparator sortPlayerByHeight = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer p1, FootballPlayer p2) {
            if (p1.getHeight().getInches() + p1.getHeight().getFeet() * 12 < (p2.getHeight().getInches() + p2.getHeight().getFeet() * 12)) {
                return -1;
            }
            if (p1.getHeight().getInches() + p1.getHeight().getFeet() * 12 == (p2.getHeight().getInches() + p2.getHeight().getFeet() * 12)) {
                return 0;
            }
            return 1;
        }
    };

    private Comparator sortPlayerByWeight = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer p1, FootballPlayer p2) {
            if (p1.getWeight() < (p2.getWeight())) {
                return -1;
            }
            if (p1.getWeight() == (p2.getWeight())) {
                return 0;
            }
            return 1;
        }
    };

    private Comparator sortPlayerByHometown = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer p1, FootballPlayer p2) {
            return p1.getHometown().compareTo(p2.getHometown());
        }
    };

    private Comparator sortPlayerByHighschool = new Comparator<FootballPlayer>() {
        @Override
        public int compare(FootballPlayer p1, FootballPlayer p2) {
            return p1.getHighSchool().compareTo(p2.getHighSchool());
        }
    };

    @Override
    public void sort() {
        if (sortField == 0) {
            Collections.sort(players, sortPlayerByNumber);
        }
        if (sortField == 1) {
            Collections.sort(players, sortPlayerByPosition);
        }
        if (sortField == 2) {
            Collections.sort(players, sortPlayerByName);
        }
        if (sortField == 3) {
            Collections.sort(players, sortPlayerByHeight);
        }
        if (sortField == 4) {
            Collections.sort(players, sortPlayerByWeight);
        }
        if (sortField == 5) {
            Collections.sort(players, sortPlayerByHometown);
        }
        if (sortField == 6) {
            Collections.sort(players, sortPlayerByHighschool);
        }
    }

    @Override
    public int getSortField() {
        return sortField;
    }

    @Override
    public void SetSortField(int sortField) {
        this.sortField = sortField;
    }

    public Comparator getSortPlayerByNumber() {
        return sortPlayerByNumber;
    }

    public void setSortPlayerByNumber(Comparator sortPlayerByNumber) {
        this.sortPlayerByNumber = sortPlayerByNumber;
    }

    public Comparator getSortPlayerByName() {
        return sortPlayerByName;
    }

    public void setSortPlayerByName(Comparator sortPlayerByName) {
        this.sortPlayerByName = sortPlayerByName;
    }

    public Comparator getSortPlayerByPosition() {
        return sortPlayerByPosition;
    }

    public void setSortPlayerByPosition(Comparator sortPlayerByPosition) {
        this.sortPlayerByPosition = sortPlayerByPosition;
    }

    public Comparator getSortPlayerByHeight() {
        return sortPlayerByHeight;
    }

    public void setSortPlayerByHeight(Comparator sortPlayerByHeight) {
        this.sortPlayerByHeight = sortPlayerByHeight;
    }

    public Comparator getSortPlayerByWeight() {
        return sortPlayerByWeight;
    }

    public void setSortPlayerByWeight(Comparator sortPlayerByWeight) {
        this.sortPlayerByWeight = sortPlayerByWeight;
    }

    public Comparator getSortPlayerByHometown() {
        return sortPlayerByHometown;
    }

    public void setSortPlayerByHometown(Comparator sortPlayerByHometown) {
        this.sortPlayerByHometown = sortPlayerByHometown;
    }

    public Comparator getSortPlayerByHighschool() {
        return sortPlayerByHighschool;
    }

    public void setSortPlayerByHighschool(Comparator sortPlayerByHighschool) {
        this.sortPlayerByHighschool = sortPlayerByHighschool;
    }

    public ArrayList<TableMember> getPlayers() {
        return players;
    }

    public void setPlayers(ArrayList<TableMember> players) {
        this.players = players;
    }

}
